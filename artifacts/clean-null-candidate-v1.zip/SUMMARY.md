# Benchmark evidence

Mode: Measure; cases: 1; preflight: Full.

Use benchmark-run.json for scenario contracts and compare only verified bundles. Smoke and control/model runs are not production baselines.
