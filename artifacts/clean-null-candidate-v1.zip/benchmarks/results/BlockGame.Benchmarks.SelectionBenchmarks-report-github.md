```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9457/25H2/2025Update/HudsonValley2)
AMD Ryzen 9 7900X 4.70GHz, 1 CPU, 24 logical and 12 physical cores
.NET SDK 10.0.103
  [Host]  : .NET 10.0.3 (10.0.3, 10.0.326.7603), X64 RyuJIT x86-64-v4
  Measure : .NET 10.0.3 (10.0.3, 10.0.326.7603), X64 RyuJIT x86-64-v4

Job=Measure  EnvironmentVariables=EDWINCRAFT_BENCHMARK_EVIDENCE=C:\Dev\project-opencode-work\out\pipeline-clean-null-verified\candidate\benchmarks\children  Jit=RyuJit  
Platform=X64  PowerPlanMode=00000000-0000-0000-0000-000000000000  Server=False  
Toolchain=.NET 10  

```
| Method                  | Scenario | Mean     | Error   | StdDev  | Gen0     | Gen1     | Gen2     | Allocated |
|------------------------ |--------- |---------:|--------:|--------:|---------:|---------:|---------:|----------:|
| CalculateAndAllocateSet | typical  | 455.7 μs | 2.92 μs | 2.73 μs | 142.5781 | 142.5781 | 142.5781 | 562.63 KB |
